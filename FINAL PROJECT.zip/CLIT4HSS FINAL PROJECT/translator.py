# -*- coding: utf-8 -*-


from googletrans import Translator

#Translating a txt file

import os

here = os.path.dirname(os.path.abspath(__file__))

filename = os.path.join(here, 'Webbnyheter_2013_KarnkraftSUBST.txt')

f = open(filename, 'r',  encoding = 'utf8')

contents = f.read()
# print(contents)

import unicodedata
clean_text = unicodedata.normalize("NFKD",contents)

contents_list = clean_text.split(",")
f.close()

for str in contents_list:
    str = str.replace(u'\xa0',u' ')
    
# print(contents_list)

import time
import pickle

translator = Translator()
newlist = []

del str
i = 0
while True:
    line = contents_list[i]
    try:
        transline = translator.translate(line, dest='en')
        i += 1
    except:
        with open('ENG_Webbnyheter_2013_' + str(i), 'wb') as fp:
            pickle.dump(newlist, fp)
        time.sleep(100)
    newlist.append(transline.text)
    print(transline.text)
    if i == len(contents_list): 
        break
    


with open('ENG_Webbnyheter_2013', 'wb') as fp:
    pickle.dump(newlist, fp)
    

