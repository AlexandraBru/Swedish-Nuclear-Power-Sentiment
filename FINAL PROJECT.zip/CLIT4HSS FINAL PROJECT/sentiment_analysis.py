# -*- coding: utf-8 -*-
# import SentimentIntensityAnalyzer class
# from vaderSentiment.vaderSentiment module.
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
 
# function to print sentiments
# of the sentence.
def sentiment_scores(sentence):
 
    # Create a SentimentIntensityAnalyzer object.
    sid_obj = SentimentIntensityAnalyzer()
 
    # polarity_scores method of SentimentIntensityAnalyzer
    # object gives a sentiment dictionary.
    # which contains pos, neg, neu, and compound scores.
    sentiment_dict = sid_obj.polarity_scores(sentence)
     
    print("Overall sentiment dictionary is : ", sentiment_dict)
    print("sentence was rated as ", sentiment_dict['neg']*100, "% Negative")
    print("sentence was rated as ", sentiment_dict['neu']*100, "% Neutral")
    print("sentence was rated as ", sentiment_dict['pos']*100, "% Positive")
 
    print("Sentence Overall Rated As", end = " ")
 
    # decide sentiment as positive, negative and neutral
    if sentiment_dict['compound'] >= 0.05 :
        print("Positive")
 
    elif sentiment_dict['compound'] <= - 0.05 :
        print("Negative")
 
    else :
        print("Neutral")

import pickle

#2009

with open ('ENG_Webbnyheter_2009_288', 'rb') as fp:
    itemlist = pickle.load(fp)
with open ('ENG_Webbnyheter_2009_288-777', 'rb') as fp:
    itemlist2 = pickle.load(fp)

listToStr = ' '.join([str(elem) for elem in itemlist])
listToStr2 = ' '.join([str(elem) for elem in itemlist2])

TOTAL2009 = listToStr + listToStr2

#2010

with open ('ENG_Webbnyheter_2010_601', 'rb') as fp:
    itemlist3 = pickle.load(fp)
with open ('ENG_Webbnyheter_2010_601-1025', 'rb') as fp:
    itemlist4 = pickle.load(fp)

listToStr3 = ' '.join([str(elem) for elem in itemlist3])
listToStr4 = ' '.join([str(elem) for elem in itemlist4])

TOTAL2010 = listToStr3 + listToStr4

#2012

with open ('ENG_Webbnyheter_2012_135', 'rb') as fp:
    itemlist5 = pickle.load(fp)
with open ('ENG_Webbnyheter_2012_135-674', 'rb') as fp:
    itemlist6 = pickle.load(fp)

listToStr5 = ' '.join([str(elem) for elem in itemlist5])
listToStr6 = ' '.join([str(elem) for elem in itemlist6])

TOTAL2012 = listToStr5 + listToStr6

#2013

with open ('ENG_Webbnyheter_2013', 'rb') as fp:
    itemlist7 = pickle.load(fp)
TOTAL2013 = ' '.join([str(elem) for elem in itemlist7])

# Driver code
if __name__ == "__main__" :
    
    print("\n2009:")
    sentence = TOTAL2009
    sentiment_scores(sentence)
    
    print("\n2010:")
    sentence = TOTAL2010
    sentiment_scores(sentence)
    
    print("\n2012:")
    sentence = TOTAL2012
    sentiment_scores(sentence)
    
    print("\n2013:")
    sentence = TOTAL2013
    sentiment_scores(sentence)